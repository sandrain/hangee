<h1>32-bit Upload</h1>

<form method="POST" action="<?=$upload_url?>" enctype="multipart/form-data">

<input type="file" name="file" value="">

<input type="submit" name="submit" value="Upload file">

</form>
