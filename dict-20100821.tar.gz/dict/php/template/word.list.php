<?foreach($word_list as $v) {?>
<a href="javascript:showWord('<?=sh($v)?>')"><?=sh($v)?></a><br/>
<?}?>