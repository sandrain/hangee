<h1>Upload dictionary</h1>

<form method="POST" action="?m=upload.post" enctype="multipart/form-data">
<input type="file" name="file" value="">
<input type="submit" name="submit" value="Upload file">
</form>