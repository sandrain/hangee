<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"><html lang="en"><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>WebDict</title>
<script src="js/jquery-1.4.2.min.js"></script>
<script src="js/jquery-ui-1.8.1.custom.min.js"></script>
<script src="js/jquery.layout.min.js"></script>
<link rel="stylesheet" type="text/css" href="js/article-style.css" />
</head><body>

<h1>Admin area</h1>

<a href="?m=admin.reindex">Reindex dictionaries</a>

</body>
</html>
