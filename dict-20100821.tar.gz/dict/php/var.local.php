<?
$config['db_host'] = "localhost";
$config['db_user'] = "";
$config['db_password'] = "";
$config['db_database'] = "";
$config['debug'] = true;


$config['admin_password'] = "";


Z::configMerge($config);
?>
