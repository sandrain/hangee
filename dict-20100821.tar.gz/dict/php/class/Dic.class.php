<?php

class Dic {
	const DIC_NEW = 1;
	const DIC_GOOD = 2;
	const DIC_BAD = 3;

    function Dic() {
    }
}
?>